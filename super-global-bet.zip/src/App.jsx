import React from "react";
import HeadsOrTailsGame from "./components/HeadsOrTailsGame";

function App() {
  return (
    <div>
      <HeadsOrTailsGame />
    </div>
  );
}

export default App;
