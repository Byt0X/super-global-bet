# 🎲 SUPER GLOBAL BET

**Juego social P2P tipo “Cara o Sello” desarrollado con React + Socket.IO.**

Los usuarios apuestan COINS, juegan entre sí en tiempo real, y el ganador se lleva todo.

## 🔗 Demo

- Frontend: https://super-global-bet.vercel.app
- Backend: https://super-global-bet-server.onrender.com

## 🛠️ Instalación

```bash
npm install
npm run dev
```

---

Creado por Gustavo Piedrahita
